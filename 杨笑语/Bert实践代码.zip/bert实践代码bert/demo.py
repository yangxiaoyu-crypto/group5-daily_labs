"""
快速演示脚本
用于快速测试BERT微调的完整流程（使用示例数据）
"""
import torch
from torch.utils.data import DataLoader
from FCModel import FCModel
from MRPCDataset import MRPCDataset
from transformers import BertTokenizer, BertModel
from tqdm import tqdm


def collate_fn(batch):
    """
    自定义批处理函数
    将batch中的句子对和标签正确组织
    """
    sentences = []
    labels = []
    for sentence_pair, label in batch:
        sentences.append(sentence_pair)
        labels.append(label)
    return sentences, torch.tensor(labels)


def quick_demo():
    """
    快速演示训练流程
    使用少量数据进行快速测试
    """
    print("="*60)
    print("BERT微调 - 快速演示")
    print("="*60)
    
    # 1. 配置
    print("\n1. 配置参数...")
    batch_size = 4
    num_samples = 20  # 只使用少量样本
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"   设备: {device}")
    print(f"   批次大小: {batch_size}")
    print(f"   样本数量: {num_samples}")
    
    # 2. 加载数据
    print("\n2. 加载示例数据...")
    try:
        dataset = MRPCDataset()
        # 限制数据量以加快演示速度
        if len(dataset) > num_samples:
            dataset.data = dataset.data[:num_samples]
            dataset.labels = dataset.labels[:num_samples]
        
        data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
        print(f"   ✓ 数据加载成功，共{len(dataset)}条")
    except Exception as e:
        print(f"   ✗ 数据加载失败: {e}")
        return
    
    # 3. 加载模型
    print("\n3. 加载模型...")
    try:
        print("   正在加载BERT tokenizer...")
        tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        print("   ✓ Tokenizer加载成功")
        
        print("   正在加载BERT模型（首次需下载，约500MB）...")
        bert_model = BertModel.from_pretrained("bert-base-uncased")
        bert_model.to(device)
        print("   ✓ BERT模型加载成功")
        
        model = FCModel()
        model.to(device)
        print("   ✓ 分类器模型创建成功")
    except Exception as e:
        print(f"   ✗ 模型加载失败: {e}")
        print("   提示: 首次运行需要从Hugging Face下载模型，请确保网络连接正常")
        return
    
    # 4. 配置优化器
    print("\n4. 配置优化器...")
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=0.00001)
    criterion = torch.nn.BCELoss()
    print("   ✓ 优化器配置完成")
    
    # 5. 训练一个epoch
    print("\n5. 开始训练（1个epoch）...")
    bert_model.train()
    model.train()
    
    epoch_loss = 0.
    epoch_acc = 0.
    total_len = 0
    
    try:
        progress_bar = tqdm(data_loader, desc='训练中')
        
        for i, data in enumerate(progress_bar):
            sentences, label = data
            label = label.to(device)
            
            # Tokenize (sentences是一个包含句子对的列表)
            encoding = tokenizer(sentences, return_tensors='pt', 
                               padding=True, truncation=True, max_length=128)
            
            # BERT编码
            bert_output = bert_model(**encoding.to(device))
            pooler_output = bert_output.pooler_output
            
            # 分类
            predict = model(pooler_output).squeeze()
            
            # 损失
            loss = criterion(predict, label.float())
            
            # 准确率
            rounded_predict = torch.round(predict)
            correct = (rounded_predict == label).float()
            acc = correct.sum() / len(correct)
            
            # 反向传播
            optimizer.zero_grad()
            bert_optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            bert_optimizer.step()
            
            # 统计
            epoch_loss += loss.item() * len(label)
            epoch_acc += acc.item() * len(label)
            total_len += len(label)
            
            # 更新进度条
            progress_bar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{acc.item():.4f}'
            })
        
        avg_loss = epoch_loss / total_len
        avg_acc = epoch_acc / total_len
        
        print(f"\n   ✓ 训练完成")
        print(f"   平均损失: {avg_loss:.4f}")
        print(f"   平均准确率: {avg_acc:.4f}")
        
    except Exception as e:
        print(f"\n   ✗ 训练过程出错: {e}")
        return
    
    # 6. 测试推理
    print("\n6. 测试模型推理...")
    bert_model.eval()
    model.eval()
    
    try:
        with torch.no_grad():
            # 获取一个样本
            test_sentences, test_label = dataset[0]
            print(f"\n   测试样本:")
            print(f"   句子1: {test_sentences[0]}")
            print(f"   句子2: {test_sentences[1]}")
            print(f"   真实标签: {test_label} ({'同义' if test_label == 1 else '不同义'})")
            
            # 推理
            encoding = tokenizer([test_sentences], return_tensors='pt',
                               padding=True, truncation=True, max_length=128)
            bert_output = bert_model(**encoding.to(device))
            pooler_output = bert_output.pooler_output
            predict = model(pooler_output).squeeze()
            
            pred_label = int(torch.round(predict).item())
            pred_prob = predict.item()
            
            print(f"   预测标签: {pred_label} ({'同义' if pred_label == 1 else '不同义'})")
            print(f"   预测概率: {pred_prob:.4f}")
            print(f"   {'✓ 预测正确' if pred_label == test_label else '✗ 预测错误'}")
    
    except Exception as e:
        print(f"   ✗ 推理测试失败: {e}")
        return
    
    # 7. 总结
    print("\n" + "="*60)
    print("演示完成！")
    print("="*60)
    print("\n✅ 完整流程测试通过，包括:")
    print("   • 数据加载")
    print("   • 模型初始化")
    print("   • 训练循环")
    print("   • 模型推理")
    print("\n💡 接下来你可以:")
    print("   1. 运行完整训练: python train.py")
    print("   2. 查看文档: 快速开始指南.md")
    print("   3. 生成可视化: python visualization_example.py")
    print("="*60)


if __name__ == "__main__":
    try:
        quick_demo()
    except KeyboardInterrupt:
        print("\n\n用户中断演示")
    except Exception as e:
        print(f"\n\n演示过程出错: {e}")
        print("请运行 python test_modules.py 检查环境配置")

