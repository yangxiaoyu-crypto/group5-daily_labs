"""
课程强度可视化示例
生成Class Dense Vector和Class Dense Matrix的可视化图表
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def generate_dense_vector_example():
    """
    生成单周课程强度向量可视化
    """
    # 示例数据：一周每天的课程节数
    weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    intensity = [6, 4, 8, 5, 6, 0, 2]  # 每天的课程节数
    
    # 定义颜色映射
    def get_color(value):
        if value == 0:
            return '#E8E8E8'  # 灰色 - 无课
        elif value <= 2:
            return '#AEC6CF'  # 浅蓝 - 低强度
        elif value <= 4:
            return '#77B5FE'  # 蓝色 - 中强度
        elif value <= 6:
            return '#318CE7'  # 深蓝 - 高强度
        else:
            return '#FF6B6B'  # 红色 - 很高强度
    
    colors = [get_color(i) for i in intensity]
    
    # 创建水平条形图
    fig, ax = plt.subplots(figsize=(12, 6))
    
    bars = ax.barh(weekdays, intensity, color=colors, edgecolor='black', linewidth=1.5)
    
    # 添加数值标签
    for i, (bar, val) in enumerate(zip(bars, intensity)):
        if val > 0:
            ax.text(val + 0.2, i, f'{val}节', va='center', fontsize=11, fontweight='bold')
    
    # 设置标题和标签
    ax.set_xlabel('课程强度（节数）', fontsize=13, fontweight='bold')
    ax.set_title('数据科学专业 - 第5周课程强度', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlim(0, 10)
    
    # 添加网格
    ax.grid(axis='x', linestyle='--', alpha=0.3)
    
    # 添加图例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#E8E8E8', edgecolor='black', label='无课/空闲'),
        Patch(facecolor='#AEC6CF', edgecolor='black', label='低强度 (1-2节)'),
        Patch(facecolor='#77B5FE', edgecolor='black', label='中强度 (3-4节)'),
        Patch(facecolor='#318CE7', edgecolor='black', label='高强度 (5-6节)'),
        Patch(facecolor='#FF6B6B', edgecolor='black', label='很高强度 (7+节)')
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    plt.tight_layout()
    plt.savefig('course_dense_vector.png', dpi=300, bbox_inches='tight')
    print("✓ 已生成课程强度向量图：course_dense_vector.png")
    plt.show()


def generate_dense_matrix_example():
    """
    生成课程强度矩阵可视化（四年八学期）
    """
    # 示例数据：8个学期 × 7天的课程强度
    semesters = ['大一上', '大一下', '大二上', '大二下', '大三上', '大三下', '大四上', '大四下']
    weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    
    # 生成模拟数据
    np.random.seed(42)
    data = np.array([
        [6, 5, 7, 6, 6, 0, 1],   # 大一上
        [6, 7, 6, 7, 5, 0, 2],   # 大一下
        [7, 6, 7, 6, 6, 2, 2],   # 大二上 - 课程最多
        [6, 7, 7, 6, 6, 0, 0],   # 大二下
        [7, 7, 6, 7, 6, 0, 3],   # 大三上 - 课程最多
        [6, 6, 7, 6, 6, 0, 2],   # 大三下
        [4, 6, 4, 6, 4, 0, 0],   # 大四上 - 开始减少
        [2, 4, 2, 4, 2, 0, 0],   # 大四下 - 明显减少
    ])
    
    # 创建热力图
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 使用seaborn绘制热力图
    im = sns.heatmap(
        data,
        annot=True,  # 显示数值
        fmt='d',     # 整数格式
        cmap='YlOrRd',  # 黄-橙-红渐变
        xticklabels=weekdays,
        yticklabels=semesters,
        cbar_kws={'label': '课程强度（节数）', 'shrink': 0.8},
        linewidths=1.5,
        linecolor='white',
        ax=ax,
        vmin=0,
        vmax=8
    )
    
    # 设置标题
    ax.set_title('计算机科学专业 - 四年课程强度矩阵', 
                 fontsize=18, fontweight='bold', pad=20)
    
    # 设置坐标轴标签
    ax.set_xlabel('星期', fontsize=14, fontweight='bold')
    ax.set_ylabel('学期', fontsize=14, fontweight='bold')
    
    # 调整刻度标签
    ax.tick_params(axis='both', labelsize=12)
    
    # 添加分析文字
    analysis_text = (
        "观察:\n"
        "• 大二和大三课程强度最大\n"
        "• 周末通常安排较少\n"
        "• 大四逐渐减少，为毕业准备"
    )
    
    plt.text(1.15, 0.5, analysis_text, 
             transform=ax.transAxes,
             fontsize=11,
             verticalalignment='center',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
    
    plt.tight_layout()
    plt.savefig('course_dense_matrix.png', dpi=300, bbox_inches='tight')
    print("✓ 已生成课程强度矩阵图：course_dense_matrix.png")
    plt.show()


def generate_comparison_chart():
    """
    生成多专业对比图
    """
    # 三个专业的平均周课程强度
    majors = ['计算机科学', '数据科学', '软件工程', '人工智能']
    
    # 每个专业四年的平均周课程强度
    data = {
        '大一': [28, 26, 27, 25],
        '大二': [32, 34, 30, 33],
        '大三': [30, 32, 28, 31],
        '大四': [15, 16, 14, 17]
    }
    
    # 创建分组柱状图
    x = np.arange(len(majors))
    width = 0.2
    
    fig, ax = plt.subplots(figsize=(12, 7))
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
    
    for i, (year, values) in enumerate(data.items()):
        offset = width * (i - 1.5)
        bars = ax.bar(x + offset, values, width, label=year, color=colors[i], 
                      edgecolor='black', linewidth=1.2)
        
        # 添加数值标签
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.5,
                   f'{int(height)}',
                   ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    # 设置标题和标签
    ax.set_xlabel('专业', fontsize=13, fontweight='bold')
    ax.set_ylabel('平均周课程强度（节/周）', fontsize=13, fontweight='bold')
    ax.set_title('不同专业课程强度对比', fontsize=16, fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(majors, fontsize=12)
    ax.legend(title='年级', fontsize=11, title_fontsize=12)
    ax.set_ylim(0, 40)
    
    # 添加网格
    ax.grid(axis='y', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('major_comparison.png', dpi=300, bbox_inches='tight')
    print("✓ 已生成专业对比图：major_comparison.png")
    plt.show()


def main():
    """
    主函数：生成所有可视化示例
    """
    print("="*60)
    print("课程强度可视化示例生成器")
    print("="*60)
    
    print("\n1. 生成课程强度向量图...")
    generate_dense_vector_example()
    
    print("\n2. 生成课程强度矩阵图...")
    generate_dense_matrix_example()
    
    print("\n3. 生成专业对比图...")
    generate_comparison_chart()
    
    print("\n" + "="*60)
    print("所有可视化图表生成完成！")
    print("="*60)


if __name__ == "__main__":
    main()

