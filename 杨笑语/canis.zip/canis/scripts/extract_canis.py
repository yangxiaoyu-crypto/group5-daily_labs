import argparse
import os
import re
from pathlib import Path
from typing import List, Dict

import pdfplumber


def find_term_in_pdf(pdf_path: Path, term: str, context: int = 120) -> Dict:
    pattern = re.compile(re.escape(term), re.IGNORECASE)
    hits: List[Dict] = []

    with pdfplumber.open(str(pdf_path)) as pdf:
        for idx, page in enumerate(pdf.pages, start=1):
            try:
                text = page.extract_text() or ""
            except Exception:
                text = ""

            page_hits = []
            for m in pattern.finditer(text):
                start = max(m.start() - context, 0)
                end = min(m.end() + context, len(text))
                snippet = text[start:end].replace("\n", " ")
                page_hits.append({
                    "page": idx,
                    "start": m.start(),
                    "end": m.end(),
                    "snippet": snippet
                })

            if page_hits:
                hits.extend(page_hits)

    return {
        "term": term,
        "total_hits": len(hits),
        "hits": hits,
    }


def save_results(base_dir: Path, result: Dict, pdf_path: Path):
    out_dir = base_dir / "output"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Human-readable summary
    summary_txt = out_dir / "canis_hits.txt"
    lines = []
    lines.append(f"PDF: {pdf_path.name}")
    lines.append(f"Search term: {result['term']}")
    lines.append(f"Total hits: {result['total_hits']}")
    lines.append("")

    # Group by page for readability
    by_page: Dict[int, List[Dict]] = {}
    for h in result["hits"]:
        by_page.setdefault(h["page"], []).append(h)

    for page in sorted(by_page.keys()):
        lines.append(f"--- Page {page} ---")
        for i, h in enumerate(by_page[page], start=1):
            snippet = h["snippet"]
            # Light highlight by wrapping first occurrence in []
            hl = re.sub(re.escape(result['term']), lambda m: f"[{m.group(0)}]", snippet, count=1, flags=re.IGNORECASE)
            lines.append(f"Hit {i}: {hl}")
        lines.append("")

    summary_txt.write_text("\n".join(lines), encoding="utf-8")

    print(f"Saved summary: {summary_txt}")
    print("Next: open the summary to identify the exact section and requirements for implementation.")


def main():
    parser = argparse.ArgumentParser(description="Extract occurrences of a term from a PDF with context.")
    parser.add_argument("--pdf", dest="pdf", default="12-interaction.pdf", help="Path to the PDF file (default: 12-interaction.pdf)")
    parser.add_argument("--term", dest="term", default="canis", help="Search term (default: canis)")
    parser.add_argument("--context", dest="context", type=int, default=120, help="Context characters around hit (default: 120)")
    args = parser.parse_args()

    pdf_path = Path(args.pdf)
    if not pdf_path.exists():
        # Also try relative to this script
        alt = Path(__file__).resolve().parent.parent / pdf_path.name
        if alt.exists():
            pdf_path = alt
        else:
            raise FileNotFoundError(f"PDF not found: {args.pdf}")

    base_dir = Path(__file__).resolve().parent.parent
    result = find_term_in_pdf(pdf_path, args.term, args.context)
    save_results(base_dir, result, pdf_path)

    if result["total_hits"] == 0:
        print("No occurrences found. Try a different term (e.g., 'CANIS', 'Canis').")


if __name__ == "__main__":
    main()
