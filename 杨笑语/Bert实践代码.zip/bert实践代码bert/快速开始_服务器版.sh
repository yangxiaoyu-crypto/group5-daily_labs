#!/bin/bash
# BERT项目 - 服务器快速启动脚本
# 在服务器上运行此脚本

echo "========================================"
echo "BERT项目 - 快速启动"
echo "========================================"
echo ""

# 激活环境
echo "步骤1: 激活gpu_env环境..."
source /home/bioinfo202200101012/anaconda3/etc/profile.d/conda.sh 2>/dev/null || source /home/bioinfo202200101012/miniconda3/etc/profile.d/conda.sh
conda activate gpu_env

# 检查环境
echo ""
echo "步骤2: 检查环境..."
echo "Python版本: $(python --version)"
echo "PyTorch版本: $(python -c 'import torch; print(torch.__version__)' 2>/dev/null || echo '未安装')"
echo "CUDA可用: $(python -c 'import torch; print(torch.cuda.is_available())' 2>/dev/null || echo 'False')"

# 检查GPU
echo ""
echo "步骤3: 检查GPU状态..."
nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv,noheader 2>/dev/null || echo "GPU信息获取失败"

# 进入项目目录
echo ""
echo "步骤4: 进入项目目录..."
cd /home/bioinfo202200101012/bert || { echo "错误: 项目目录不存在！"; exit 1; }
echo "当前目录: $(pwd)"

# 询问操作
echo ""
echo "========================================"
echo "请选择操作:"
echo "  1) 环境测试 (test_modules.py)"
echo "  2) 快速演示 (demo.py)"
echo "  3) 完整训练 (train.py)"
echo "  4) 后台训练 (nohup)"
echo "  5) 评估模型 (evaluate.py)"
echo "  6) 生成可视化 (visualization_example.py)"
echo "  7) 查看训练日志 (train.log)"
echo "  8) 查看GPU状态"
echo "  9) 退出"
echo "========================================"
echo ""
read -p "请输入选项 (1-9): " choice

case $choice in
    1)
        echo "运行环境测试..."
        python test_modules.py
        ;;
    2)
        echo "运行快速演示..."
        python demo.py
        ;;
    3)
        echo "运行完整训练..."
        read -p "训练轮数 (默认3): " epochs
        epochs=${epochs:-3}
        read -p "批次大小 (默认16): " batch_size
        batch_size=${batch_size:-16}
        python train.py --num_epochs $epochs --batch_size $batch_size
        ;;
    4)
        echo "后台运行训练..."
        read -p "训练轮数 (默认3): " epochs
        epochs=${epochs:-3}
        read -p "批次大小 (默认16): " batch_size
        batch_size=${batch_size:-16}
        nohup python train.py --num_epochs $epochs --batch_size $batch_size > train.log 2>&1 &
        echo "训练已在后台启动！"
        echo "进程ID: $!"
        echo "查看日志: tail -f train.log"
        ;;
    5)
        echo "评估模型..."
        latest_checkpoint=$(ls -t checkpoints/*.pt 2>/dev/null | head -1)
        if [ -z "$latest_checkpoint" ]; then
            echo "错误: 未找到模型检查点！"
        else
            echo "使用检查点: $latest_checkpoint"
            python evaluate.py --checkpoint "$latest_checkpoint" --show_examples
        fi
        ;;
    6)
        echo "生成可视化..."
        python visualization_example.py
        echo "图片已生成！"
        ls -lh *.png 2>/dev/null || echo "未找到PNG文件"
        ;;
    7)
        echo "查看训练日志..."
        if [ -f "train.log" ]; then
            tail -30 train.log
            echo ""
            read -p "实时查看日志? (y/n): " view_live
            if [ "$view_live" = "y" ]; then
                tail -f train.log
            fi
        else
            echo "错误: train.log 不存在！"
        fi
        ;;
    8)
        echo "GPU状态:"
        nvidia-smi
        ;;
    9)
        echo "退出"
        exit 0
        ;;
    *)
        echo "无效选项！"
        exit 1
        ;;
esac

echo ""
echo "========================================"
echo "操作完成！"
echo "========================================"

