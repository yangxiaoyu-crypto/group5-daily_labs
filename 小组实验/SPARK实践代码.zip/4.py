from pyspark.sql import SparkSession
from pyspark.sql.functions import to_date, dayofweek

# 初始化SparkSession
spark = SparkSession.builder \
    .appName("StoreDailyAvgTraffic") \
    .config("spark.hadoop.fs.defaultFS", "file:///") \
    .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
    .getOrCreate()

try:
    # 加载数据
    sales_data = spark.read.csv(
        "sales_data.csv",
        header=True,
        inferSchema=True
    )
    
    # 计算每个地区的工作日日均订单量
    store_daily_avg = sales_data \
        .filter(dayofweek(to_date("Date", "yyyy/MM/dd")).between(2, 6)) \
        .filter("Order_Quantity > 0") \
        .groupBy("State") \
        .avg("Order_Quantity") \
        .withColumnRenamed("avg(Order_Quantity)", "avg_order_quantity") \
        .orderBy("avg_order_quantity", ascending=False)
    
    # 显示结果
    print("每个地区的工作日日均订单量：")
    store_daily_avg.show(20)
finally:
    # 停止会话
    spark.stop()
