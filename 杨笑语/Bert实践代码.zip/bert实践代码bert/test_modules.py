"""
模块测试脚本
快速验证所有模块是否正常工作
"""
import sys

def test_imports():
    """测试依赖包导入"""
    print("="*60)
    print("1. 测试依赖包导入...")
    print("-"*60)
    
    packages = {
        'torch': 'PyTorch',
        'transformers': 'Transformers',
        'pandas': 'Pandas',
        'numpy': 'NumPy',
        'sklearn': 'Scikit-learn',
        'tqdm': 'tqdm',
        'matplotlib': 'Matplotlib',
        'seaborn': 'Seaborn'
    }
    
    failed = []
    for package, name in packages.items():
        try:
            __import__(package)
            print(f"✓ {name:20s} - 已安装")
        except ImportError:
            print(f"✗ {name:20s} - 未安装")
            failed.append(name)
    
    if failed:
        print(f"\n警告: 以下包未安装: {', '.join(failed)}")
        print("请运行: pip install -r requirements.txt")
        return False
    else:
        print("\n✓ 所有依赖包已安装")
        return True


def test_cuda():
    """测试CUDA可用性"""
    print("\n" + "="*60)
    print("2. 测试CUDA/GPU...")
    print("-"*60)
    
    try:
        import torch
        
        print(f"PyTorch版本: {torch.__version__}")
        print(f"CUDA可用: {torch.cuda.is_available()}")
        
        if torch.cuda.is_available():
            print(f"CUDA版本: {torch.version.cuda}")
            print(f"GPU数量: {torch.cuda.device_count()}")
            print(f"当前GPU: {torch.cuda.current_device()}")
            print(f"GPU名称: {torch.cuda.get_device_name(0)}")
            print(f"GPU显存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
        else:
            print("未检测到GPU，将使用CPU训练（速度较慢）")
    except Exception as e:
        print(f"错误: {e}")
        return False
    
    return True


def test_dataset():
    """测试数据集模块"""
    print("\n" + "="*60)
    print("3. 测试数据集模块...")
    print("-"*60)
    
    try:
        from MRPCDataset import MRPCDataset
        
        # 创建数据集实例（会自动生成示例数据）
        dataset = MRPCDataset()
        print(f"✓ 数据集创建成功")
        print(f"  数据集大小: {len(dataset)}")
        
        # 测试获取样本
        if len(dataset) > 0:
            sentences, label = dataset[0]
            print(f"  样本示例:")
            print(f"    句子1: {sentences[0][:50]}...")
            print(f"    句子2: {sentences[1][:50]}...")
            print(f"    标签: {label}")
        
        return True
    except Exception as e:
        print(f"✗ 数据集模块测试失败: {e}")
        return False


def test_model():
    """测试模型模块"""
    print("\n" + "="*60)
    print("4. 测试模型模块...")
    print("-"*60)
    
    try:
        import torch
        from FCModel import FCModel, FCModelDeep
        
        # 测试简单模型
        model = FCModel()
        print(f"✓ FCModel创建成功")
        print(f"  参数数量: {sum(p.numel() for p in model.parameters()):,}")
        
        # 测试前向传播
        batch_size = 4
        input_dim = 768
        dummy_input = torch.randn(batch_size, input_dim)
        output = model(dummy_input)
        print(f"  前向传播测试: 输入{dummy_input.shape} -> 输出{output.shape}")
        
        # 测试深层模型
        model_deep = FCModelDeep()
        print(f"✓ FCModelDeep创建成功")
        print(f"  参数数量: {sum(p.numel() for p in model_deep.parameters()):,}")
        
        return True
    except Exception as e:
        print(f"✗ 模型模块测试失败: {e}")
        return False


def test_bert():
    """测试BERT模型加载"""
    print("\n" + "="*60)
    print("5. 测试BERT模型加载...")
    print("-"*60)
    print("注意: 首次运行需要下载BERT模型（约500MB），可能需要几分钟...")
    
    try:
        from transformers import BertTokenizer, BertModel
        
        print("正在加载BERT tokenizer...")
        tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        print("✓ BERT tokenizer加载成功")
        
        print("正在加载BERT模型...")
        bert_model = BertModel.from_pretrained("bert-base-uncased")
        print("✓ BERT模型加载成功")
        
        # 测试tokenizer
        test_sentence = ["Hello, this is a test.", "This is another sentence."]
        encoding = tokenizer(test_sentence, return_tensors='pt', padding=True, truncation=True)
        print(f"  Tokenizer测试成功: {len(test_sentence)}个句子 -> {encoding['input_ids'].shape}")
        
        return True
    except Exception as e:
        print(f"✗ BERT模型加载失败: {e}")
        print("  可能的原因:")
        print("  1. 网络连接问题，无法下载模型")
        print("  2. transformers版本不兼容")
        print("  解决方案:")
        print("  - 检查网络连接")
        print("  - 使用镜像源或代理")
        print("  - 确保transformers版本为4.18.0")
        return False


def test_visualization():
    """测试可视化模块"""
    print("\n" + "="*60)
    print("6. 测试可视化模块...")
    print("-"*60)
    
    try:
        import matplotlib.pyplot as plt
        import seaborn as sns
        import numpy as np
        
        print("✓ Matplotlib和Seaborn导入成功")
        
        # 测试简单绘图
        fig, ax = plt.subplots(1, 1, figsize=(5, 3))
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.set_title('Test Plot')
        plt.close(fig)
        print("✓ 绘图测试成功")
        
        return True
    except Exception as e:
        print(f"✗ 可视化模块测试失败: {e}")
        return False


def main():
    """主测试函数"""
    print("\n" + "╔" + "="*58 + "╗")
    print("║" + " "*18 + "模块测试工具" + " "*28 + "║")
    print("╚" + "="*58 + "╝")
    
    results = []
    
    # 运行所有测试
    results.append(("依赖包导入", test_imports()))
    results.append(("CUDA/GPU", test_cuda()))
    results.append(("数据集模块", test_dataset()))
    results.append(("模型模块", test_model()))
    results.append(("BERT模型", test_bert()))
    results.append(("可视化模块", test_visualization()))
    
    # 汇总结果
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    for name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{name:20s}: {status}")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    print("-"*60)
    print(f"总计: {passed}/{total} 项测试通过")
    
    if passed == total:
        print("\n🎉 所有测试通过！环境配置完成，可以开始训练了。")
        print("\n快速开始:")
        print("  python train.py --num_epochs 3 --batch_size 16")
    else:
        print("\n⚠️ 部分测试未通过，请检查上述错误信息。")
        print("   可以先解决依赖包问题，然后重新运行此测试。")
    
    print("="*60)


if __name__ == "__main__":
    main()

