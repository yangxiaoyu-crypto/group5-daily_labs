import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 设置中文字体（避免中文乱码）
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统
# plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']  # Mac系统
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 读取数据
df = pd.read_csv('Light.csv')

# 数据预处理：将seconds_elapsed转换为更易读的分钟格式（可选）
df['minutes_elapsed'] = df['seconds_elapsed'] / 60

# 创建画布和子图
plt.figure(figsize=(12, 6))

# 绘制折线图
plt.plot(df['minutes_elapsed'], df['lux'],
         color='#2ec7c9',  # 线条颜色
         linewidth=2.5,    # 线条宽度
         marker='o',       # 标记点样式
         markersize=6,     # 标记点大小
         markerfacecolor='#ffb980',  # 标记点填充色
         markeredgecolor='white',    # 标记点边框色
         markeredgewidth=1,          # 标记点边框宽度
         label='光照强度')

# 设置坐标轴标签和标题
plt.xlabel('时间（分钟）', fontsize=12, fontweight='bold')
plt.ylabel('光照强度（lux）', fontsize=12, fontweight='bold')
plt.title('不同时刻光照强度变化趋势', fontsize=16, fontweight='bold', pad=20)

# 优化坐标轴刻度
plt.xticks(np.arange(0, df['minutes_elapsed'].max() + 1, 0.5), rotation=45)
plt.yticks(np.arange(0, df['lux'].max() + 50, 50))

# 添加网格线（增强可读性）
plt.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)

# 添加数值标注（标记关键节点）
for i, row in df.iterrows():
    if i % 2 == 0:  # 每隔1个点标注，避免过于密集
        plt.annotate(f"{row['lux']:.1f}",
                     xy=(row['minutes_elapsed'], row['lux']),
                     xytext=(5, 5), textcoords='offset points',
                     fontsize=9, color='#59678c', fontweight='medium')

# 添加图例
plt.legend(loc='upper right', fontsize=11, framealpha=0.9)

# 调整布局（防止标签被截断）
plt.tight_layout()

# 保存图片（可选，分辨率300dpi）
plt.savefig('光照强度变化折线图.png', dpi=300, bbox_inches='tight')

# 显示图片
plt.show()

# 输出数据统计信息（辅助分析）
print("光照强度统计信息：")
print(f"数据采集时长：{df['seconds_elapsed'].max():.2f} 秒（{df['minutes_elapsed'].max():.2f} 分钟）")
print(f"最大光照强度：{df['lux'].max():.2f} lux")
print(f"最小光照强度：{df['lux'].min():.2f} lux")
print(f"平均光照强度：{df['lux'].mean():.2f} lux")