"""
MRPC数据集处理类
用于加载和预处理Microsoft Research Paraphrase Corpus数据集
"""
import torch
from torch.utils.data import Dataset
import pandas as pd
import os


class MRPCDataset(Dataset):
    """
    MRPC数据集类，用于处理句子对的同义判断任务
    数据格式: Quality, #1 ID, #2 ID, #1 String, #2 String
    """
    
    def __init__(self, data_path='data/msr_paraphrase_train.txt', max_length=128):
        """
        初始化数据集
        
        Args:
            data_path: 数据文件路径
            max_length: 句子最大长度
        """
        self.max_length = max_length
        self.data = []
        self.labels = []
        
        # 检查数据文件是否存在
        if not os.path.exists(data_path):
            print(f"警告: 数据文件 {data_path} 不存在!")
            print("请从以下链接下载MRPC数据集:")
            print("https://www.microsoft.com/en-us/download/details.aspx?id=52398")
            print("并将 msr_paraphrase_train.txt 放置在 data/ 目录下")
            # 创建示例数据用于测试
            self._create_dummy_data()
        else:
            self._load_data(data_path)
    
    def _load_data(self, data_path):
        """从文件加载数据"""
        try:
            # 读取TSV格式的数据
            df = pd.read_csv(data_path, sep='\t', encoding='utf-8', on_bad_lines='skip')
            
            # MRPC数据集格式: Quality, #1 ID, #2 ID, #1 String, #2 String
            for idx, row in df.iterrows():
                if idx == 0:  # 跳过表头
                    continue
                    
                try:
                    # 第一列是标签(0或1)
                    label = int(row.iloc[0])
                    # 第4和第5列是两个句子
                    sentence1 = str(row.iloc[3])
                    sentence2 = str(row.iloc[4])
                    
                    # 拼接两个句子，使用[SEP]分隔
                    sentence_pair = [sentence1, sentence2]
                    
                    self.data.append(sentence_pair)
                    self.labels.append(label)
                except Exception as e:
                    continue
            
            print(f"成功加载 {len(self.data)} 条数据")
            
        except Exception as e:
            print(f"加载数据时出错: {e}")
            self._create_dummy_data()
    
    def _create_dummy_data(self):
        """创建示例数据用于测试"""
        print("创建示例数据用于测试...")
        dummy_data = [
            (["The bird is flying in the sky.", "A bird flies in the air."], 1),
            (["I love machine learning.", "Machine learning is fascinating."], 1),
            (["The weather is nice today.", "I don't like rainy days."], 0),
            (["He is reading a book.", "She is writing a letter."], 0),
            (["The cat is sleeping.", "A cat is taking a nap."], 1),
        ] * 20  # 复制数据以便训练
        
        for sentence_pair, label in dummy_data:
            self.data.append(sentence_pair)
            self.labels.append(label)
        
        print(f"创建了 {len(self.data)} 条示例数据")
    
    def __len__(self):
        """返回数据集大小"""
        return len(self.data)
    
    def __getitem__(self, idx):
        """
        获取单个数据样本
        
        Returns:
            sentence_pair: 句子对列表 [sentence1, sentence2]
            label: 标签(0或1)
        """
        return self.data[idx], self.labels[idx]


class MRPCTestDataset(MRPCDataset):
    """MRPC测试数据集类"""
    
    def __init__(self, data_path='data/msr_paraphrase_test.txt', max_length=128):
        """
        初始化测试数据集
        
        Args:
            data_path: 测试数据文件路径
            max_length: 句子最大长度
        """
        super().__init__(data_path, max_length)


if __name__ == "__main__":
    # 测试数据集加载
    print("测试MRPC数据集加载...")
    dataset = MRPCDataset()
    print(f"数据集大小: {len(dataset)}")
    
    # 显示前3个样本
    print("\n前3个样本:")
    for i in range(min(3, len(dataset))):
        sentences, label = dataset[i]
        print(f"\n样本 {i+1}:")
        print(f"  句子1: {sentences[0]}")
        print(f"  句子2: {sentences[1]}")
        print(f"  标签: {label} ({'同义' if label == 1 else '不同义'})")

