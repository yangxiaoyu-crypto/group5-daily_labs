"""
BERT微调训练脚本
使用BERT预训练模型对MRPC数据集进行句子对同义判断任务的微调
"""
import torch
from torch.utils.data import DataLoader
from FCModel import FCModel, FCModelDeep
from MRPCDataset import MRPCDataset
from transformers import BertTokenizer, BertModel
import os
import argparse
from tqdm import tqdm


def collate_fn(batch):
    """
    自定义批处理函数
    """
    sentences = []
    labels = []
    for sentence_pair, label in batch:
        sentences.append(sentence_pair)
        labels.append(label)
    return sentences, torch.tensor(labels)


def binary_accuracy(predict, label):
    """
    计算二分类准确率
    
    Args:
        predict: 预测值，shape为(batch_size,)，值在0-1之间
        label: 真实标签，shape为(batch_size,)，值为0或1
    
    Returns:
        accuracy: 准确率
    """
    rounded_predict = torch.round(predict)
    correct = (rounded_predict == label).float()
    accuracy = correct.sum() / len(correct)
    return accuracy


def train_epoch(train_loader, bert_model, model, optimizer, bert_optimizer, 
                criterion, device, epoch):
    """
    训练一个epoch
    
    Args:
        train_loader: 训练数据加载器
        bert_model: BERT模型
        model: 分类器模型
        optimizer: 分类器优化器
        bert_optimizer: BERT优化器
        criterion: 损失函数
        device: 运行设备
        epoch: 当前epoch数
    
    Returns:
        epoch_loss: 平均损失
        epoch_acc: 平均准确率
    """
    # 记录统计信息
    epoch_loss, epoch_acc = 0., 0.
    total_len = 0
    
    # 设置为训练模式
    bert_model.train()
    model.train()
    
    # 使用tqdm显示进度条
    train_iterator = tqdm(train_loader, desc=f'Epoch {epoch}', leave=True)
    
    # 分batch进行训练
    for i, data in enumerate(train_iterator):
        sentences, label = data
        label = label.to(device)
        
        # 使用BERT tokenizer处理句子对
        # sentences是一个列表，每个元素是[sentence1, sentence2]
        tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        encoding = tokenizer(sentences, return_tensors='pt', padding=True, 
                           truncation=True, max_length=128)
        
        # 通过BERT获取句子表示
        bert_output = bert_model(**encoding.to(device))
        pooler_output = bert_output.pooler_output  # shape: (batch_size, 768)
        
        # 通过分类器获取预测结果
        predict = model(pooler_output).squeeze()  # shape: (batch_size,)
        
        # 计算损失和准确率
        loss = criterion(predict, label.float())
        acc = binary_accuracy(predict, label)
        
        # 梯度下降
        optimizer.zero_grad()  # 重置梯度
        bert_optimizer.zero_grad()
        loss.backward()  # 反向传播
        optimizer.step()  # 更新参数
        bert_optimizer.step()
        
        # 累计统计信息
        epoch_loss += loss.item() * len(label)
        epoch_acc += acc.item() * len(label)
        total_len += len(label)
        
        # 更新进度条
        train_iterator.set_postfix(loss=loss.item(), acc=acc.item())
    
    return epoch_loss / total_len, epoch_acc / total_len


def save_checkpoint(bert_model, model, optimizer, bert_optimizer, epoch, 
                   loss, acc, save_dir='checkpoints'):
    """
    保存模型检查点
    
    Args:
        bert_model: BERT模型
        model: 分类器模型
        optimizer: 分类器优化器
        bert_optimizer: BERT优化器
        epoch: 当前epoch
        loss: 当前损失
        acc: 当前准确率
        save_dir: 保存目录
    """
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    checkpoint = {
        'epoch': epoch,
        'bert_state_dict': bert_model.state_dict(),
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'bert_optimizer_state_dict': bert_optimizer.state_dict(),
        'loss': loss,
        'acc': acc
    }
    
    save_path = os.path.join(save_dir, f'checkpoint_epoch_{epoch}.pt')
    torch.save(checkpoint, save_path)
    print(f"检查点已保存至: {save_path}")


def main(args):
    """主训练函数"""
    
    print("="*50)
    print("BERT微调训练 - MRPC数据集")
    print("="*50)
    
    # 载入数据预处理模块
    print("\n1. 加载数据集...")
    mrpc_dataset = MRPCDataset(data_path=args.data_path)
    train_loader = DataLoader(dataset=mrpc_dataset, batch_size=args.batch_size, 
                             shuffle=True, num_workers=0, collate_fn=collate_fn)
    print(f"数据载入完成，共{len(mrpc_dataset)}条训练数据")
    
    # 设置运行设备
    print("\n2. 配置运行设备...")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    if torch.cuda.is_available():
        print(f"GPU型号: {torch.cuda.get_device_name(0)}")
        print(f"GPU显存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
    
    # 加载BERT模型
    print("\n3. 加载BERT预训练模型...")
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    bert_model = BertModel.from_pretrained("bert-base-uncased")
    bert_model.to(device)
    print("BERT模型加载完成")
    
    # 创建分类器模型
    print("\n4. 创建分类器模型...")
    if args.model_type == 'simple':
        model = FCModel(dropout=args.dropout)
    else:
        model = FCModelDeep(dropout=args.dropout)
    model = model.to(device)
    print(f"分类器模型创建完成 (类型: {args.model_type})")
    print(f"模型参数数量: {sum(p.numel() for p in model.parameters()):,}")
    
    # 定义优化器和损失函数
    print("\n5. 配置优化器和损失函数...")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=args.bert_lr)
    criterion = torch.nn.BCELoss()
    print(f"学习率 - 分类器: {args.lr}, BERT: {args.bert_lr}")
    
    # 开始训练
    print("\n6. 开始训练...")
    print("="*50)
    
    best_acc = 0.0
    for epoch in range(1, args.num_epochs + 1):
        epoch_loss, epoch_acc = train_epoch(
            train_loader, bert_model, model, optimizer, bert_optimizer,
            criterion, device, epoch
        )
        
        print(f"\nEPOCH {epoch}/{args.num_epochs} - Loss: {epoch_loss:.4f}, Accuracy: {epoch_acc:.4f}")
        
        # 保存最佳模型
        if epoch_acc > best_acc:
            best_acc = epoch_acc
            save_checkpoint(bert_model, model, optimizer, bert_optimizer,
                          epoch, epoch_loss, epoch_acc, args.save_dir)
            print(f"★ 最佳准确率更新: {best_acc:.4f}")
        
        print("-"*50)
    
    print("\n训练完成!")
    print(f"最佳准确率: {best_acc:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='BERT微调训练 - MRPC数据集')
    
    # 数据参数
    parser.add_argument('--data_path', type=str, 
                       default='data/msr_paraphrase_train.txt',
                       help='训练数据路径')
    
    # 模型参数
    parser.add_argument('--model_type', type=str, default='simple',
                       choices=['simple', 'deep'],
                       help='分类器模型类型')
    parser.add_argument('--dropout', type=float, default=0.3,
                       help='Dropout比率')
    
    # 训练参数
    parser.add_argument('--batch_size', type=int, default=16,
                       help='批次大小')
    parser.add_argument('--num_epochs', type=int, default=3,
                       help='训练轮数')
    parser.add_argument('--lr', type=float, default=0.001,
                       help='分类器学习率')
    parser.add_argument('--bert_lr', type=float, default=0.00001,
                       help='BERT学习率')
    
    # 保存参数
    parser.add_argument('--save_dir', type=str, default='checkpoints',
                       help='模型保存目录')
    
    args = parser.parse_args()
    
    main(args)

