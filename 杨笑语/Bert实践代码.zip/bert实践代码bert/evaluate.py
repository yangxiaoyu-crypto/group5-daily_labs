"""
模型评估脚本
用于在测试集上评估训练好的BERT微调模型
"""
import torch
from torch.utils.data import DataLoader
from FCModel import FCModel, FCModelDeep
from MRPCDataset import MRPCTestDataset
from transformers import BertTokenizer, BertModel
import argparse
from tqdm import tqdm
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix


def collate_fn(batch):
    """
    自定义批处理函数
    """
    sentences = []
    labels = []
    for sentence_pair, label in batch:
        sentences.append(sentence_pair)
        labels.append(label)
    return sentences, torch.tensor(labels)


def evaluate(test_loader, bert_model, model, device, tokenizer):
    """
    在测试集上评估模型
    
    Args:
        test_loader: 测试数据加载器
        bert_model: BERT模型
        model: 分类器模型
        device: 运行设备
        tokenizer: BERT tokenizer
    
    Returns:
        metrics: 评估指标字典
    """
    # 设置为评估模式
    bert_model.eval()
    model.eval()
    
    all_predictions = []
    all_labels = []
    all_probs = []
    
    # 不计算梯度
    with torch.no_grad():
        test_iterator = tqdm(test_loader, desc='评估中', leave=True)
        
        for data in test_iterator:
            sentences, label = data
            label = label.to(device)
            
            # 使用BERT tokenizer处理句子对
            encoding = tokenizer(sentences, return_tensors='pt', padding=True,
                               truncation=True, max_length=128)
            
            # 通过BERT获取句子表示
            bert_output = bert_model(**encoding.to(device))
            pooler_output = bert_output.pooler_output
            
            # 通过分类器获取预测结果
            predict = model(pooler_output).squeeze()
            
            # 收集预测结果和标签
            all_probs.extend(predict.cpu().numpy().tolist())
            all_predictions.extend(torch.round(predict).cpu().numpy().tolist())
            all_labels.extend(label.cpu().numpy().tolist())
    
    # 计算各种评估指标
    all_predictions = np.array(all_predictions)
    all_labels = np.array(all_labels)
    all_probs = np.array(all_probs)
    
    metrics = {
        'accuracy': accuracy_score(all_labels, all_predictions),
        'precision': precision_score(all_labels, all_predictions, zero_division=0),
        'recall': recall_score(all_labels, all_predictions, zero_division=0),
        'f1': f1_score(all_labels, all_predictions, zero_division=0),
        'confusion_matrix': confusion_matrix(all_labels, all_predictions)
    }
    
    return metrics, all_predictions, all_labels, all_probs


def print_metrics(metrics):
    """
    打印评估指标
    
    Args:
        metrics: 评估指标字典
    """
    print("\n" + "="*50)
    print("评估结果")
    print("="*50)
    print(f"准确率 (Accuracy):  {metrics['accuracy']:.4f}")
    print(f"精确率 (Precision): {metrics['precision']:.4f}")
    print(f"召回率 (Recall):    {metrics['recall']:.4f}")
    print(f"F1分数 (F1-Score):  {metrics['f1']:.4f}")
    print("\n混淆矩阵 (Confusion Matrix):")
    print(metrics['confusion_matrix'])
    print("-"*50)
    print("混淆矩阵说明:")
    print(f"  真负例(TN): {metrics['confusion_matrix'][0][0]}")
    print(f"  假正例(FP): {metrics['confusion_matrix'][0][1]}")
    print(f"  假负例(FN): {metrics['confusion_matrix'][1][0]}")
    print(f"  真正例(TP): {metrics['confusion_matrix'][1][1]}")
    print("="*50)


def load_checkpoint(checkpoint_path, bert_model, model, device):
    """
    加载模型检查点
    
    Args:
        checkpoint_path: 检查点文件路径
        bert_model: BERT模型
        model: 分类器模型
        device: 运行设备
    
    Returns:
        checkpoint: 检查点信息
    """
    print(f"正在加载检查点: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    bert_model.load_state_dict(checkpoint['bert_state_dict'])
    model.load_state_dict(checkpoint['model_state_dict'])
    
    print(f"检查点加载完成 (Epoch {checkpoint['epoch']}, Loss: {checkpoint['loss']:.4f}, Acc: {checkpoint['acc']:.4f})")
    
    return checkpoint


def main(args):
    """主评估函数"""
    
    print("="*50)
    print("BERT微调模型评估 - MRPC数据集")
    print("="*50)
    
    # 载入测试数据
    print("\n1. 加载测试数据集...")
    test_dataset = MRPCTestDataset(data_path=args.test_data_path)
    test_loader = DataLoader(dataset=test_dataset, batch_size=args.batch_size,
                            shuffle=False, num_workers=0, collate_fn=collate_fn)
    print(f"测试数据加载完成，共{len(test_dataset)}条测试数据")
    
    # 设置运行设备
    print("\n2. 配置运行设备...")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 加载BERT模型
    print("\n3. 加载BERT模型...")
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    bert_model = BertModel.from_pretrained("bert-base-uncased")
    bert_model.to(device)
    
    # 创建分类器模型
    print("\n4. 创建分类器模型...")
    if args.model_type == 'simple':
        model = FCModel()
    else:
        model = FCModelDeep()
    model = model.to(device)
    
    # 加载训练好的模型权重
    if args.checkpoint:
        print("\n5. 加载训练好的模型...")
        load_checkpoint(args.checkpoint, bert_model, model, device)
    else:
        print("\n警告: 未指定检查点文件，将使用随机初始化的模型进行评估")
    
    # 开始评估
    print("\n6. 开始评估...")
    metrics, predictions, labels, probs = evaluate(
        test_loader, bert_model, model, device, tokenizer
    )
    
    # 打印评估结果
    print_metrics(metrics)
    
    # 显示一些预测样例
    if args.show_examples:
        print("\n预测样例:")
        print("-"*50)
        num_examples = min(5, len(test_dataset))
        for i in range(num_examples):
            sentences, label = test_dataset[i]
            pred = predictions[i]
            prob = probs[i]
            print(f"\n样例 {i+1}:")
            print(f"  句子1: {sentences[0][:60]}...")
            print(f"  句子2: {sentences[1][:60]}...")
            print(f"  真实标签: {int(label)} ({'同义' if label == 1 else '不同义'})")
            print(f"  预测标签: {int(pred)} ({'同义' if pred == 1 else '不同义'})")
            print(f"  预测概率: {prob:.4f}")
            print(f"  {'✓ 正确' if pred == label else '✗ 错误'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='BERT微调模型评估 - MRPC数据集')
    
    # 数据参数
    parser.add_argument('--test_data_path', type=str,
                       default='data/msr_paraphrase_test.txt',
                       help='测试数据路径')
    
    # 模型参数
    parser.add_argument('--model_type', type=str, default='simple',
                       choices=['simple', 'deep'],
                       help='分类器模型类型')
    parser.add_argument('--checkpoint', type=str, default=None,
                       help='模型检查点路径')
    
    # 评估参数
    parser.add_argument('--batch_size', type=int, default=16,
                       help='批次大小')
    parser.add_argument('--show_examples', action='store_true',
                       help='是否显示预测样例')
    
    args = parser.parse_args()
    
    main(args)

