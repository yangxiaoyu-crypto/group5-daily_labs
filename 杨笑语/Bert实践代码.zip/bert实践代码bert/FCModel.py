"""
全连接层分类模型
用于将BERT的输出转换为二分类结果
"""
import torch
import torch.nn as nn


class FCModel(nn.Module):
    """
    全连接层分类模型
    使用两层MLP(多层感知机)进行二分类
    """
    
    def __init__(self, input_dim=768, hidden_dim=256, output_dim=1, dropout=0.3):
        """
        初始化模型
        
        Args:
            input_dim: 输入维度，BERT-base的pooler_output维度为768
            hidden_dim: 隐藏层维度
            output_dim: 输出维度，二分类任务为1
            dropout: Dropout比率，防止过拟合
        """
        super(FCModel, self).__init__()
        
        # 第一层全连接层
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        # 激活函数
        self.relu = nn.ReLU()
        # Dropout层，防止过拟合
        self.dropout = nn.Dropout(dropout)
        # 第二层全连接层
        self.fc2 = nn.Linear(hidden_dim, output_dim)
        # Sigmoid激活函数，输出0-1之间的概率
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入张量，shape为(batch_size, input_dim)
        
        Returns:
            输出张量，shape为(batch_size, output_dim)，值在0-1之间
        """
        # 第一层：全连接 -> ReLU -> Dropout
        out = self.fc1(x)
        out = self.relu(out)
        out = self.dropout(out)
        
        # 第二层：全连接 -> Sigmoid
        out = self.fc2(out)
        out = self.sigmoid(out)
        
        return out


class FCModelDeep(nn.Module):
    """
    深层全连接层分类模型
    使用三层MLP进行二分类，可能获得更好的性能
    """
    
    def __init__(self, input_dim=768, hidden_dim1=512, hidden_dim2=256, 
                 output_dim=1, dropout=0.3):
        """
        初始化深层模型
        
        Args:
            input_dim: 输入维度
            hidden_dim1: 第一个隐藏层维度
            hidden_dim2: 第二个隐藏层维度
            output_dim: 输出维度
            dropout: Dropout比率
        """
        super(FCModelDeep, self).__init__()
        
        # 三层全连接网络
        self.fc1 = nn.Linear(input_dim, hidden_dim1)
        self.fc2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.fc3 = nn.Linear(hidden_dim2, output_dim)
        
        # 激活函数和正则化
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        
        # Batch Normalization，加速训练和提高稳定性
        self.bn1 = nn.BatchNorm1d(hidden_dim1)
        self.bn2 = nn.BatchNorm1d(hidden_dim2)
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入张量，shape为(batch_size, input_dim)
        
        Returns:
            输出张量，shape为(batch_size, output_dim)
        """
        # 第一层
        out = self.fc1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.dropout(out)
        
        # 第二层
        out = self.fc2(out)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.dropout(out)
        
        # 输出层
        out = self.fc3(out)
        out = self.sigmoid(out)
        
        return out


if __name__ == "__main__":
    # 测试模型
    print("测试FCModel...")
    model = FCModel()
    print(model)
    print(f"\n模型参数数量: {sum(p.numel() for p in model.parameters())}")
    
    # 测试前向传播
    batch_size = 16
    input_dim = 768
    dummy_input = torch.randn(batch_size, input_dim)
    output = model(dummy_input)
    print(f"\n输入shape: {dummy_input.shape}")
    print(f"输出shape: {output.shape}")
    print(f"输出范围: [{output.min().item():.4f}, {output.max().item():.4f}]")
    
    print("\n" + "="*50)
    print("测试FCModelDeep...")
    model_deep = FCModelDeep()
    print(model_deep)
    print(f"\n模型参数数量: {sum(p.numel() for p in model_deep.parameters())}")
    
    output_deep = model_deep(dummy_input)
    print(f"\n输入shape: {dummy_input.shape}")
    print(f"输出shape: {output_deep.shape}")
    print(f"输出范围: [{output_deep.min().item():.4f}, {output_deep.max().item():.4f}]")

