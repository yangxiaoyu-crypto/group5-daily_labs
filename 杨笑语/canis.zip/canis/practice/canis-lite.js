function by(arr, fn) { return Array.from(arr).map(fn); }
function groupBy(arr, keyFn) { const m = new Map(); arr.forEach(it => { const k = keyFn(it); if (!m.has(k)) m.set(k, []); m.get(k).push(it); }); return Array.from(m.entries()).map(([k, v]) => ({ key: k, items: v })); }
function ascend(a, b) { return a < b ? -1 : a > b ? 1 : 0; }
const Easings = { linear: t => t, "ease-out": t => 1 - Math.pow(1 - t, 2), "ease-in": t => t * t, "ease-in-out": t => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2) };
function clamp01(x) { return Math.max(0, Math.min(1, x)); }
function getNumberAttr(el, name) { return parseFloat(el.getAttribute(name) || "0"); }
function setNumberAttr(el, name, v) { el.setAttribute(name, String(v)); }
function lerp(a, b, t) { return a + (b - a) * t; }
class CanisLitePlayer {
  constructor(svg, spec) {
    this.svg = svg;
    this.spec = spec;
    this.timeline = [];
    this.playing = false;
    this.startTs = 0;
    this.pauseTs = 0;
    this._rid = 0;
    this._prepared = false;
  }
  prepare() {
    if (this._prepared) return;
    this.timeline = [];
    const animations = this.spec.animations || [];
    animations.forEach(anim => {
      const sel = anim.selector || "*";
      const nodes = Array.from(this.svg.querySelectorAll(sel));
      let items = nodes;
      const g = anim.grouping || {};
      const groupByKey = g.groupBy || null;
      const sortByKey = g.sortBy || null;
      const order = (g.order || "sequential").toLowerCase();
      const stagger = Number(g.stagger || 120);
      const groupDelay = Number(g.groupDelay || 400);
      const baseDelay = Number(anim.delay || 0);
      const duration = Number(anim.duration || 800);
      const easingName = (anim.easing || "ease-out").toLowerCase();
      const easing = Easings[easingName] || Easings["linear"];
      if (groupByKey) {
        const groups = groupBy(items, el => el.getAttribute(groupByKey) || "");
        groups.sort((a, b) => ascend(a.key, b.key));
        groups.forEach((grp, gi) => {
          let grpItems = grp.items;
          if (sortByKey) {
            grpItems = grpItems.slice().sort((a, b) => ascend(parseFloat(a.getAttribute(sortByKey) || "0"), parseFloat(b.getAttribute(sortByKey) || "0")));
          }
          const groupStart = baseDelay + gi * groupDelay;
          if (order === "simultaneous") {
            grpItems.forEach((el) => {
              this._addAnimation(el, anim, duration, groupStart, easing);
            });
          } else {
            grpItems.forEach((el, idx) => {
              const start = groupStart + idx * stagger;
              this._addAnimation(el, anim, duration, start, easing);
            });
          }
        });
      } else {
        let all = items;
        if (sortByKey) {
          all = all.slice().sort((a, b) => ascend(parseFloat(a.getAttribute(sortByKey) || "0"), parseFloat(b.getAttribute(sortByKey) || "0")));
        }
        if (order === "simultaneous") {
          all.forEach(el => this._addAnimation(el, anim, duration, baseDelay, easing));
        } else {
          all.forEach((el, idx) => this._addAnimation(el, anim, duration, baseDelay + idx * stagger, easing));
        }
      }
    });
    // initialize elements to their pre-animation states
    this.timeline.forEach(a => this._applyProgress(a, 0));
    this._prepared = true;
  }
  _addAnimation(el, anim, duration, start, easing) {
    const effects = anim.effects || [];
    const finalOp = parseFloat(getComputedStyle(el).opacity || "1");
    let wipeDir = null;
    let doFade = false;
    let wantsGrow = false;
    let wantsDraw = false;
    for (const ef of effects) {
      const t = (ef.type || "").toLowerCase();
      if (t === "wipe") wipeDir = (ef.direction || "bottom").toLowerCase();
      if (t === "fade") doFade = true;
      if (t === "grow") wantsGrow = true;
      if (t === "draw") wantsDraw = true;
    }
    const tag = el.tagName.toLowerCase();
    const entry = { el, start, duration, easing, doFade, opacity: { start: doFade ? 0 : finalOp, end: finalOp } };
    if (tag === "rect") {
      const finalX = getNumberAttr(el, "x");
      const finalY = getNumberAttr(el, "y");
      const finalW = getNumberAttr(el, "width");
      const finalH = getNumberAttr(el, "height");
      const orientation = (el.getAttribute("data-orientation") || (finalH >= finalW ? "vertical" : "horizontal")).toLowerCase();
      if (orientation === "horizontal") {
        const dir = wipeDir || "right";
        const startX = dir === "left" ? finalX + finalW : finalX;
        entry.kind = "rect-horizontal";
        entry.dims = {
          x: { start: startX, end: finalX },
          width: { start: 0, end: finalW }
        };
      } else {
        const dir = wipeDir || "bottom";
        const startY = dir === "top" ? finalY : finalY + finalH;
        entry.kind = "rect-vertical";
        entry.dims = {
          y: { start: startY, end: finalY },
          height: { start: 0, end: finalH }
        };
      }
    } else if (tag === "circle") {
      const finalR = getNumberAttr(el, "r");
      entry.kind = "circle";
      entry.dims = {
        r: { start: wantsGrow ? 0 : finalR, end: finalR }
      };
    } else if (tag === "path") {
      const length = typeof el.getTotalLength === "function" ? el.getTotalLength() : 0;
      entry.kind = "path";
      entry.pathLength = length;
      entry.wantsDraw = wantsDraw || true;
    } else {
      entry.kind = "generic";
    }
    this.timeline.push(entry);
  }
  reset() {
    cancelAnimationFrame(this._rid);
    this._rid = 0;
    this.playing = false;
    this._prepared = false;
    if (this.timeline.length) {
      this.timeline.forEach(a => this._applyProgress(a, 0));
    } else {
      const rects = this.svg.querySelectorAll(".bar");
      rects.forEach(r => {
        r.style.opacity = "0";
        const y = getNumberAttr(r, "y");
        const h = getNumberAttr(r, "height");
        setNumberAttr(r, "height", 0);
        setNumberAttr(r, "y", y + h);
      });
    }
  }
  play() {
    this.prepare();
    this.playing = true;
    this.startTs = performance.now();
    this.pauseTs = 0;
    this._tick();
  }
  pause() {
    if (!this.playing) return;
    this.playing = false;
    this.pauseTs = performance.now();
    cancelAnimationFrame(this._rid);
  }
  resume() {
    if (this.playing || !this.pauseTs) return;
    const delta = performance.now() - this.pauseTs;
    this.timeline.forEach(a => a.start += delta);
    this.playing = true;
    this._tick();
  }
  _tick() {
    const now = performance.now();
    let active = false;
    this.timeline.forEach(a => {
      const local = now - (this.startTs + a.start);
      if (local < 0) {
        this._applyProgress(a, 0);
        active = true;
        return;
      }
      const p = clamp01(local / a.duration);
      const e = a.easing(p);
      this._applyProgress(a, e);
      if (p < 1) active = true;
    });
    if (active && this.playing) this._rid = requestAnimationFrame(this._tick.bind(this));
  }
  _applyProgress(entry, eased) {
    switch (entry.kind) {
      case "rect-vertical": {
        const y = lerp(entry.dims.y.start, entry.dims.y.end, eased);
        const h = lerp(entry.dims.height.start, entry.dims.height.end, eased);
        setNumberAttr(entry.el, "y", y);
        setNumberAttr(entry.el, "height", h);
        break;
      }
      case "rect-horizontal": {
        const x = lerp(entry.dims.x.start, entry.dims.x.end, eased);
        const w = lerp(entry.dims.width.start, entry.dims.width.end, eased);
        setNumberAttr(entry.el, "x", x);
        setNumberAttr(entry.el, "width", w);
        break;
      }
      case "circle": {
        const r = lerp(entry.dims.r.start, entry.dims.r.end, eased);
        setNumberAttr(entry.el, "r", r);
        break;
      }
      case "path": {
        const length = entry.pathLength || 0;
        entry.el.style.strokeDasharray = length;
        entry.el.style.strokeDashoffset = length * (1 - eased);
        break;
      }
      default:
        break;
    }
    if (entry.opacity) {
      const op = lerp(entry.opacity.start, entry.opacity.end, eased);
      entry.el.style.opacity = String(op);
    }
  }
}
window.CanisLitePlayer = CanisLitePlayer;
